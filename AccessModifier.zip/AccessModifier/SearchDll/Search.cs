﻿

using Utilities.Exceptions;

namespace SearchDll
{
    public class Search
    {
        public bool IsExist(string search,string[] names)
        {
            bool exist = false;
            foreach (var name in names)
            {
                if (search.Trim().ToLower() == name.ToLower())
                {
                    exist = true;
                }
            }
            if (exist)
            {
                return true;
            }
            else
            {
                throw new NotFoundException($"{search} is not exist");
            }
        }
    }
}
