﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ClassLibrary
{
    public class Notification
    {
        internal int MyProperty { get; set; }
        protected internal string Title { get; set; }
        private protected string Message { get; set; }
    }

    class Message : Notification
    {
        public Message()
        {
            Message = "Some message";
            Console.WriteLine(Message);
            Title = "Warning";
           
        }
        public void Test()
        {
            MyProperty = 100;
            Notification n = new Notification();
            n.Title = "Hello";
            n.MyProperty = 10;
        }
    }
}
