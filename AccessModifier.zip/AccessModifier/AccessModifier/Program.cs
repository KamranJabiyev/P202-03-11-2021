﻿using AccessModifier.Models;
using AccessModifier.Models.DemoNS;
using ClassLibrary;
using SearchDll;
using System;
using System.Reflection;

namespace AccessModifier
{
    partial class Car
    {

    }
    class Program
    {
        static void Main(string[] args)
        {
            #region Access Modifiers
            #region Public - class(interface), all class members(field,method,property)
            //Car car = new Car();
            //car.Brend = "BMW";
            //Console.WriteLine(car.Brend);
            //car.Run();
            #endregion

            #region Protected-all class members
            //Car car = new Car();
            #endregion

            #region Private - all class members
            //Car car = new Car();
            //typeof(Car).GetField("_speed", BindingFlags.NonPublic | BindingFlags.Instance)
            //    .SetValue(car, 300);
            //var speed = typeof(Car).GetField("_speed", BindingFlags.NonPublic | BindingFlags.Instance)
            //    .GetValue(car);
            //Console.WriteLine(speed);
            //car.Run();
            #endregion

            #region Encapsulation
            //Car car = new Car();
            //car.SetSpeed(50);
            //Console.WriteLine(car.GetSpeed());
            //car.Speed = 300;
            //Console.WriteLine(car.Speed);
            //Car car1 = new Car("Mercedes");
            //Console.WriteLine(car1.Brand);
            #endregion

            #region readonly - field

            Models.DemoNS.Car car = new Models.DemoNS.Car();

            //Car car1 = new Car();

            //Console.WriteLine(car._hp);
            #endregion

            #region Internal - class,all class members
            //Notification notify = new Notification();
            #endregion

            #region Protected internal(private protected) - all class members
            Notification notification = new Notification();

            #endregion
            #endregion

            #region Exception
            #region try catch finally

            //Start:
            //try
            //{

            //    Console.WriteLine("Birinci ededi daxil et:");
            //    int num1 = int.Parse(Console.ReadLine());
            //    Console.WriteLine("Birinci ededi daxil et:");
            //    int num2 = int.Parse(Console.ReadLine());
            //    int result = num1 / num2;
            //}
            //catch(DivideByZeroException ex)
            //{
            //    Console.WriteLine(ex.Message);
            //    goto Start;
            //}
            //catch(ArithmeticException ex)
            //{
            //    Console.WriteLine(ex.Message);
            //}
            //catch (Exception ex)
            //{
            //    Console.WriteLine(ex.Message);
            //}
            //finally
            //{
            //    Console.WriteLine("Finally");
            //}
            #endregion
            #region ApplicationException
            Console.WriteLine("Ad daxil edin:");
            try
            {
                string name = Console.ReadLine();
                string[] names = { "Nijat", "Togrul", "Cavid", "Ramal", "Shahnaz" };
                Search search = new Search();
                Console.WriteLine(search.IsExist(name, names));
            }
            catch (Exception ex)
            {

                Console.WriteLine(ex.Message);
            }
            
            #endregion
            #endregion

        }
    }

    //class Test:Notification
    //{
    //    public Test()
    //    {
    //        Title = "Test";
    //        Console.WriteLine(Title);
    //    }
    //}

    //class Car
    //{
    //    public int MyProperty { get; set; }
    //}

    
}
