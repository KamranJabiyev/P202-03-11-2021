﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AccessModifier.Models.DemoNS
{
    class Car
    {

    }
}
